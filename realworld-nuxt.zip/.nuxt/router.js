import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _665cbdbd = () => interopDefault(import('..\\pages\\layout' /* webpackChunkName: "" */))
const _55584032 = () => interopDefault(import('..\\pages\\home' /* webpackChunkName: "" */))
const _55e80e76 = () => interopDefault(import('..\\pages\\login' /* webpackChunkName: "" */))
const _3c0f5cc3 = () => interopDefault(import('..\\pages\\article' /* webpackChunkName: "" */))
const _5a8de400 = () => interopDefault(import('..\\pages\\editor' /* webpackChunkName: "" */))
const _55451976 = () => interopDefault(import('..\\pages\\profile' /* webpackChunkName: "" */))
const _36c3b414 = () => interopDefault(import('..\\pages\\settings' /* webpackChunkName: "" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/",
    component: _665cbdbd,
    children: [{
      path: "",
      component: _55584032,
      name: "home"
    }, {
      path: "/login",
      component: _55e80e76,
      name: "login"
    }, {
      path: "/register",
      component: _55e80e76,
      name: "register"
    }, {
      path: "/article/:slug",
      component: _3c0f5cc3,
      name: "article"
    }, {
      path: "/editor/:slug",
      component: _5a8de400,
      name: "editor"
    }, {
      path: "/editor",
      component: _5a8de400,
      name: "editor"
    }, {
      path: "/profile/:username",
      component: _55451976,
      name: "profile"
    }, {
      path: "/settings",
      component: _36c3b414,
      name: "settings"
    }]
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
